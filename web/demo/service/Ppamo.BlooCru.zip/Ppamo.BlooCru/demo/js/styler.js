
function Styler(worker)
{
// Methods

// Constructor
	this.worker = worker;
}